#include <gtk/gtk.h>

int x;
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_dashboard1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_deconnexion1_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_deconnexion2_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_dashboard2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_confirmer_ajout_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_treeview1_cursor_changed            (GtkTreeView     *treeview,

                                        gpointer         user_data);

void
on_button_dashboard_before_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_deconnexion_before_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_confirmer_modifier_clicked   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_button_initialiser_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);






void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
