#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include <string.h>

int typebinome=0;

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *windowEspacefoyer,*treeview2;
char user[20];
char pasw[20];
int trouve;
username = lookup_widget (button,"entry_login");
password = lookup_widget (button,"entry_pw");

strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verif(user,pasw);
if (trouve==1)
{
windowEspacefoyer=create_interface();
gtk_widget_show(windowEspacefoyer);
treeview2=lookup_widget(windowEspacefoyer,"treeview1");
afficher_etudiant(treeview2);
}
else
{printf("not found\n");
}

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
///////////////////////
etudiant e;
GtkTreeIter iter;
gchar* id;
//gchar* cin;
//gchar* nom;
//gchar* prenom;
gchar* binome;
//gchar* email;
//gchar* tel;

gint* etage;

gint* chambre;

gint* jours;
gint* mois;
gint* annee;
gchar* classe;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model, &iter, path))
{
gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&classe,2, &binome, 3 ,&jours, 4 , &mois, 5 , &annee, 6 , &etage, 7 , &chambre ,  -1);
strcpy(e.id,id);
//strcpy(e.cin,cin);

//strcpy(e.nom,nom);
//strcpy(e.prenom,prenom);
strcpy(e.classe,classe);
strcpy(e.binome,binome);
//strcpy(e.email,email);
//strcpy(e.tel,tel);
e.dn.jours=jours;
e.dn.mois=mois;
e.dn.annee=annee;
e.chambre=chambre;
e.etage=etage;

supprimer_etudiant(e);

afficher_etudiant(treeview);
/*FILE *f;
f=fopen("tmp2.txt","a+");
fprintf(f,"%s %s %s %s %d %d %d %s \n",e.id,e.nom,e.nom,e.sexe,e.dn.jours,e.dn.mois,e.dn.annee,e.classe);
*/
}
}


void
on_button_dashboard1_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_deconnexion1_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter;

windowajouter=create_ajouter();
gtk_widget_show(windowajouter);
}


void
on_button_modifier_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/**************** heeeeeeree *********************************************/
GtkWidget *windowmodifier;

windowmodifier=create_before_modifier();
gtk_widget_show(windowmodifier);
}


void
on_button_rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *xd;
xd=create_rechercher();
gtk_widget_show(xd);
}


void
on_button_actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview2;
treeview2=lookup_widget(objet,"treeview1");
afficher_etudiant(treeview2);
}


void
on_button_deconnexion2_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_dashboard2_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_confirmer_ajout_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *id,*classe,*binome,*calendar,*spin_etage,*spin_chambre;
//char nom1[30];
//char prenom1[30];
char id1[9];
char classe1[30];
char binome1[30];
int etage1;
int chambre1;
//char cin1[9];
int jours1,mois1,annee1;
//char tel2[30];
//char email1[30];
//etudiant e;
//-------association-----------------
calendar = lookup_widget(objet_graphique, "calendar1");
//nom = lookup_widget (objet_graphique, "entry_ajouter_nom");
//prenom = lookup_widget (objet_graphique, "entry_ajouter_prenom");
classe = lookup_widget (objet_graphique, "comboboxentry2");
id = lookup_widget (objet_graphique, "entry_ajouter_id");
//cin = lookup_widget (objet_graphique, "entry_ajouter_cin");
spin_etage=lookup_widget(objet_graphique,"spinbutton1");
spin_chambre=lookup_widget(objet_graphique,"spinbutton2");
//email=lookup_widget(objet_graphique,"entry_ajouter_email");
//tel=lookup_widget(objet_graphique,"entry_ajouter_tel");

///////////////////////////
gtk_calendar_get_date(GTK_CALENDAR(calendar),&annee1,&mois1,&jours1);
//strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom)));
//strcpy(prenom1, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
//strcpy(cin1, gtk_entry_get_text(GTK_ENTRY(cin)));
//strcpy(email1, gtk_entry_get_text(GTK_ENTRY(email)));
//strcpy(tel2, gtk_entry_get_text(GTK_ENTRY(tel)));
strcpy(classe1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));
if (x==1)
{
strcpy(binome1,"Avec");
}
 else 

{
strcpy(binome1,"Sans");
}

etage1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_etage));
chambre1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_chambre));

mois1+=1;

/*rintf("\n%s",nom1);
printf("\n%s",prenom1);
printf("\n%s",id1);
printf("\n%s",cin1);
printf("\n%s",sexe1);
printf("\n%d",jours1);
printf("\n%d",mois1);
printf("\n%d",annee1);
printf("\n%d",etage1);
printf("\n%d",chambre1);
printf("\n%s",classe1);
printf("\n%s",email1);
printf("\n%s",tel2);
*/

//ouvrir le fichier 
f=fopen("utilisateur.txt","a+");
if(f!=NULL)
{
//ecrire dans le fichier
fprintf(f,"%s %s %s %d %d %d %d %d \n",id1,classe1,binome1,jours1,mois1,annee1,etage1,chambre1);
fclose(f);
}
else{
printf("\n not found");
}


}
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
//printf("\nla valeur de x est %d",x);
}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
//printf("\nla valeur de x est %d",x);
}
}




void
on_treeview1_cursor_changed            (GtkTreeView     *treeview,

                                        gpointer         user_data)
{

}

void
on_button_dashboard_before_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_deconnexion_before_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_before_modifier_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{


}


void
on_button_confirmer_modifier_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *id2,*binome2,*spin_etage2,*spin_chambre2,*classe2,*spin_jours,*spin_mois,*spin_annee;
//char nom1[30];
//char prenom1[30];
char id1[9];
char classe1[30];
char binome4[30];
int etage1;
int chambre1;
//char cin1[9];
int jours1,mois1,annee1;
/*char tel1[30];
char email1[30];*/

//////////////////////////////////////////
//nom2 = lookup_widget (objet_graphique, "entry_modifier_nom");
//prenom2 = lookup_widget (objet_graphique, "entry_modifier_prenom");
id2 = lookup_widget (objet_graphique, "entry_modifier_id");
classe2 = lookup_widget (objet_graphique, "Classe");
binome2 = lookup_widget (objet_graphique, "Binome");

//cin2 = lookup_widget (objet_graphique, "entry_modifier_cin");

//email2=lookup_widget(objet_graphique,"entry_modifier_email");
//tel2=lookup_widget(objet_graphique,"entry_modifier_tel");
spin_jours=lookup_widget(objet_graphique,"spinbutton5");
spin_mois=lookup_widget(objet_graphique,"spinbutton6");
spin_annee=lookup_widget(objet_graphique,"spinbutton7");
spin_etage2=lookup_widget(objet_graphique,"spinbutton3");
spin_chambre2=lookup_widget(objet_graphique,"spinbutton4");
//mois1+=1;

///////////////////////////

//strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom2)));
//strcpy(prenom1, gtk_entry_get_text(GTK_ENTRY(prenom2)));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id2)));
//strcpy(cin1, gtk_entry_get_text(GTK_ENTRY(cin2)));
//strcpy(email1, gtk_entry_get_text(GTK_ENTRY(email2)));
//strcpy(tel1, gtk_entry_get_text(GTK_ENTRY(tel2)));
strcpy(classe1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe2)));
strcpy(binome4,gtk_combo_box_get_active_text(GTK_COMBO_BOX(binome2)));

jours1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jours));
mois1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois));
annee1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee));
etage1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_etage2));
chambre1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_chambre2));
//strcpy(e.cin,cin1);
strcpy(e.id,id1);
strcpy(e.classe,classe1);
//strcpy(e.nom,nom1);
//strcpy(e.prenom,prenom1);
strcpy(e.binome,binome4);
//strcpy(e.email,email1);
//strcpy(e.tel,tel1);
e.dn.jours=jours1;
e.dn.mois=mois1;
e.dn.annee=annee1;
e.etage=etage1;
e.chambre=chambre1;


/*
printf("\n%s",e.cin);
printf("\n%s",e.id);
printf("\n%s",e.nom);
printf("\n%s",e.prenom);
printf("\n%s",e.sexe);
printf("\n%s",e.email);
printf("\n%s",e.tel);
printf("\n%d",e.etage);
printf("\n%d",e.chambre);
printf("\n%d",e.dn.jours);
printf("\n%d",e.dn.mois);
printf("\n%d",e.dn.annee);

printf("\n%s",e.classe);



*/

modifier(e);

}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button_initialiser_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e3;
GtkWidget *avec1,*sans1,*calendar,*id,*classe,*binome,*spin_etage,*spin_chambre,*spin_jours,*spin_mois,*spin_annee;
FILE *q=NULL;
char m[200][200]={"3B1","3B2","3B3","3B4","3B5","3B6","3B7","3B8","3B9","3B10"};
char m1[200][200]={"Avec","Sans"};
int i=0;
int j=0;
q=fopen("tmp2.txt","r");
while(fscanf(q,"%s %s %s %d %d %d %d %d \n",e3.id,e3.classe,e3.binome,&e3.dn.jours,&e3.dn.mois,&e3.dn.annee,&e3.etage,&e3.chambre)!=EOF)
{
	id = lookup_widget (objet_graphique,"entry_modifier_id");
	gtk_entry_set_text(id,e3.id);
	/*nom = lookup_widget (objet_graphique,"entry_modifier_cin");
	gtk_entry_set_text(nom,e3.cin);
	nom = lookup_widget (objet_graphique,"entry_modifier_nom");
	gtk_entry_set_text(nom,e3.nom);
	nom = lookup_widget (objet_graphique,"entry_modifier_prenom");
	gtk_entry_set_text(nom,e3.prenom);*/
	//binome = lookup_widget (objet_graphique,"comboboxentry4");
	//gtk_entry_set_text(binome,e3.binome);
	/*nom = lookup_widget (objet_graphique,"entry_modifier_email");
	gtk_entry_set_text(nom,e3.email);
	nom = lookup_widget (objet_graphique,"entry_modifier_tel");
	gtk_entry_set_text(nom,e3.tel);*/
	///////// calendar //////////

	e3.dn.mois-=1;
	/*calendar = lookup_widget(objet_graphique, "calendar2");
	gtk_calendar_set_date(GTK_CALENDAR(calendar),e3.dn.jours,e3.dn.mois,e3.dn.annee);*/
	spin_etage=lookup_widget(objet_graphique,"spinbutton3");
	spin_chambre=lookup_widget(objet_graphique,"spinbutton4");
	while ((i<10) && (strcmp(m[i],e3.classe))!=0)
	{
	i=i+1;}
	classe = lookup_widget (objet_graphique, "Classe");
	gtk_combo_box_set_active(GTK_COMBO_BOX(classe),i);
	gtk_spin_button_set_value(spin_etage,e3.etage);
	gtk_spin_button_set_value(spin_chambre,e3.chambre);

	e3.dn.mois+=1;
	while ((j<2) && (strcmp(m1[j],e3.binome))!=0)
	{
	j=j+1;}
	/*if(strcmp(e3.binome,"Avec")==0)
	{gtk_toggle_button_set_active(GTK_RADIO_BUTTON(avec1),TRUE);}
	else
	{gtk_toggle_button_set_active(GTK_RADIO_BUTTON(sans1),TRUE);}
*/
	binome = lookup_widget (objet_graphique, "Binome");
	gtk_combo_box_set_active(GTK_COMBO_BOX(binome),j);
	spin_jours=lookup_widget(objet_graphique,"spinbutton5");
	spin_mois=lookup_widget(objet_graphique,"spinbutton6");
	spin_annee=lookup_widget(objet_graphique,"spinbutton7");
	gtk_spin_button_set_value(spin_jours,e3.dn.jours);
	gtk_spin_button_set_value(spin_mois,e3.dn.mois);
	gtk_spin_button_set_value(spin_annee,e3.dn.annee);

}

//////////////modiff////////////



}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*label;

char id[20];

identifiant = lookup_widget (objet_graphique,"entry_before_modifier_id");
label=lookup_widget(objet_graphique,"indisponible");

strcpy(id, gtk_entry_get_text(GTK_ENTRY(identifiant)));

//printf("\n%s",id);

etudiant e2,e3;
GtkWidget *windowmodifier;
FILE *f,*g;
f=fopen("utilisateur.txt","r");
g=fopen("tmp2.txt","w");
if ((f!=NULL) )
{
while (fscanf(f,"%s %s %s %d %d %d %d %d \n",e2.id,e2.classe,e2.binome,&e2.dn.jours,&e2.dn.mois,&e2.dn.annee,&e2.etage,&e2.chambre)!=EOF)
{
	if (strcmp(id,e2.id)==0)
	{
	fprintf(g,"%s %s %s %d %d %d %d %d \n",e2.id,e2.classe,e2.binome,e2.dn.jours,e2.dn.mois,e2.dn.annee,e2.etage,e2.chambre);
	windowmodifier=create_modifier();
	gtk_widget_show(windowmodifier);
	}
	else
	{
	 gtk_label_set_text(label,"Identifiant introuvable !");
		//gtk_entry_set_text(id,e3.id);	
	}
}

fclose(f);
fclose(g);





}

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}





/*void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	typebinome = 1;
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	
	if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
	typebinome = 2;

}*/

