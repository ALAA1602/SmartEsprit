#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonctions.h"
#include <gtk/gtk.h>
enum
{
	ECIN,
	ENOM,
	EPRENOM,
	EMDP,
	EROLE,
	ESEXE,
	EJOUR,
	EMOIS,
	EANNEE,
	COLUMNS,
};


void  ajout_utilisateur(utilisateur t1 , int type )
{ 
   
    FILE *f=NULL;
    if (type==1)
    strcpy(t1.sexe,"homme");
    if (type==2)
    strcpy(t1.sexe,"femme");
    f=fopen("utilisateur.txt","a+");
    if(f!=NULL)
    { 
        
        fprintf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,t1.jour,t1.mois,t1.annee );
        fclose(f);
    }
    }
void supprimer_utilisateur(char log[20] )
{
	
    FILE *f=NULL;
    FILE *tmp=NULL;
    utilisateur t1  ;
    f=fopen("utilisateur.txt","r");
    tmp=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,&t1.jour,&t1.mois,&t1.annee )!=EOF)
        {
            if(strcmp(t1.cin ,  log)!=0)
            {
                fprintf(tmp,"%s %s %s %s %s %s %d %d %d \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,t1.jour,t1.mois,t1.annee);
            }

        }
        fclose(f);
        fclose(tmp);
        remove("utilisateur.txt");
        rename("tmp.txt","utilisateur.txt");

    }
    //else
      //  printf("not founded");
}


void chercher_utilisateur(char log[20] )
{
	
    FILE *f=NULL;
    FILE *tmp=NULL;
    utilisateur t1  ;
    f=fopen("utilisateur.txt","r");
    tmp=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,&t1.jour,&t1.mois,&t1.annee )!=EOF)
        {
            if(strcmp(t1.cin ,  log)==0)
            {
                fprintf(tmp,"%s %s %s %s %s %s %d %d %d \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,t1.jour,t1.mois,t1.annee);
            }

        }
        fclose(f);
        fclose(tmp);
      //  remove("utilisateur.txt");
     //   rename("tmp.txt","utilisateur.txt");

    }
    //else
      //  printf("not founded");
}








void modifer_utilisateur(char log[20] , utilisateur t2 , int type)
{ 
    /*FILE *f=NULL;
    FILE *tmp=NULL;
    utilisateur t1  ;
    f=fopen("utilisateur.txt","r");
    tmp=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",t.nom,t.prenom,t.cin,t.mdp,t.role,t.sexe,t.jour,t.mois,t.annee )!=EOF)
        {
            if(strcmp(t1.cin ,  log)!=0)
            {
                fprintf(tmp,"%s %s %s %s %s %s %d %d %d \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t.sexe,t1.jour,t1.mois,t1.annee);
            }
        else
{
fprintf(f,"%s %s %s %s %s %s %d %d %d \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t.sexe,t1.jour,t1.mois,t1.annee );
}

        
        fclose(f);
        fclose(tmp);
        remove("utilisateur.txt");
        rename("tmp.txt","utilisateur.txt");

   
}
}*/
    supprimer_utilisateur(log);
    ajout_utilisateur(t2 , type);
}
/*int chercher_utilisateur(utilisateur *p)
{
    FILE *f=NULL;
    utilisateur t1;
    int teste;
    char log[20];
    f=fopen("utilisateur.txt","r");
    teste=0;
      printf("Donner cin :");scanf("%s",log);	
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d\n",t1.cin,t1.mdp,t1.nom,t1.prenom,&t1.role  )!=EOF)
        {
            if(strcmp(t1.cin, log)==0)
            {
                *p=t1;
                teste=1;
                break;
            }
	    else 
		 printf("not founded");


        }
        
    }
fclose(f);
    
    return(teste);
}*/
void afficher_utilisateur(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char cin[20];
	char mdp[20];
	char role[20];
	char nom[20];
	char prenom[20];
	char sexe[20] ;
	char jour[20];
	char mois[20];
	char annee[20];
	
	store=NULL;

	FILE *f;

	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
 
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
 
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mdp", renderer, "text", EMDP, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("role", renderer, "text",EROLE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",ESEXE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column); 




	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING );

	f=fopen("utilisateur.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f = fopen("utilisateur.txt","a+");
	while(fscanf(f, "%s %s %s %s %s %s %s %s %s  \n",nom,prenom,cin,mdp,role,sexe,jour,mois,annee)!=EOF)
	{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ECIN,cin,EMDP,mdp,EROLE,role,ESEXE,sexe,EJOUR,jour,EMOIS,mois,EANNEE,annee, -1);
	}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref (store);
	}
	}
}


//////////////////////////////////:



void affchercher_utilisateur(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char cin[20];
	char mdp[20];
	char role[20];
	char nom[20];
	char prenom[20];
	char sexe[20] ;
	char jour[20];
	char mois[20];
	char annee[20];
	
	store=NULL;

	FILE *f;

	store = gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
 
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
 
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mdp", renderer, "text", EMDP, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("role", renderer, "text",EROLE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",ESEXE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column); 




	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING );

	f=fopen("tmp.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
	f = fopen("tmp.txt","a+");
	while(fscanf(f, "%s %s %s %s %s %s %s %s %s  \n",nom,prenom,cin,mdp,role,sexe,jour,mois,annee)!=EOF)
	{
		gtk_list_store_append(store,&iter);
		gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ECIN,cin,EMDP,mdp,EROLE,role,ESEXE,sexe,EJOUR,jour,EMOIS,mois,EANNEE,annee, -1);
	}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref (store);
	}
	}
}
	
	

	
