#ifndef Capteur_h
#define Capteur_h
#include <string.h>
#include <gtk/gtk.h>

typedef struct
{
	char Ref[30];
	char etat[30];
	char grandeur[30];
	int Valmax;
	int Valmin;
	char typedit[30];
	char Gp[30];
	char typesort[30];
}Capteur;

void Ajouter_Capteur(Capteur C,int type_det,int type_sort[]);
void afficher_capteur(GtkWidget *liste);
void Modifier_Capteur(char Ref3[20]);
//void supprimer_capteur(char Ref[20]);
void supprimer_capteur(char Ref2[20]);
void afficherr_capteur(GtkWidget *liste);
void chercher1_utilisateur(char Ref[20] );


#endif
