#include <gtk/gtk.h>


void
on_ajout_Cap_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

gboolean
on_treeview_select_cursor_row         (GtkTreeView     *treeview,
                                        gboolean         start_editing,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_avec_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_sans_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_analogique_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_num__rique_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_numerique_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


//////////////

void
on_Ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_sup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

gboolean
on_treeview1_button_press_event        (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



/////////////////////////////


int x;
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

/*void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
*/
void
on_button_dashboard1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_deconnexion1_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);



void
on_button_rechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_deconnexion2_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_dashboard2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_confirmer_ajout_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_treeview2_cursor_changed            (GtkTreeView     *treeview,

                                        gpointer         user_data);

void
on_button_dashboard_before_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_deconnexion_before_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_confirmer_modifier_clicked   (GtkWidget      *objet_graphique,
                                        gpointer         user_data);


void
on_button_initialiser_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);






void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_connecter_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_creecompte_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscrire_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_connecter2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttontechnicien_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonetudiant_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonfoyer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonnut_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Deconnecter1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_membre_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Deconnecter2_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Deconncter3_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Deconncter5_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher1_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
