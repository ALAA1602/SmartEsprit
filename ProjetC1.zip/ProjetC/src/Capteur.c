#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Capteur.h"
#include <gtk/gtk.h>

//static FILE *f;
//static Capteur C;

enum 
{
	EREF,
	EGP,
	EVALMAX,
	EVALMIN,
	ETYPESORT,
	ETYPEDIT,
	EETAT,
	COLUMNS,

};



void chercher1_utilisateur(char Ref[20] )
{
	
    FILE *f=NULL;
    FILE *tmp1=NULL;
    Capteur C  ;
    f=fopen("Capteur.txt","r");
    tmp1=fopen("tmp1.txt","w");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s \n",C.Ref,C.Gp,&C.Valmax,&C.Valmin,C.typesort,C.typedit,C.etat)!=EOF)
        {
            if(strcmp(C.Ref ,  Ref)==0)
            {
                fprintf(tmp1,"%s %s %d %d %s %s %s \n",C.Ref,C.Gp,C.Valmax,C.Valmin,C.typesort,C.typedit,C.etat);
            }

        }
        fclose(f);
        fclose(tmp1);
      //  remove("utilisateur.txt");
     //   rename("tmp.txt","utilisateur.txt");

    }
    //else
      //  printf("not founded");
}
void Ajouter_Capteur(Capteur C,int type_det,int type_sort[])
{
	FILE *f=NULL;
	//Capteur C;
	if (type_det ==1)
	strcpy(C.typedit,"Avec");
	if(type_det==2)
	strcpy(C.typedit,"Sans");
	f=fopen("Capteur.txt","a+");
	if(type_sort==0)
	strcpy(C.typesort,"Analogique");
	if(type_sort==1)
	strcpy(C.typesort,"Numerique");
	
	if(f!=NULL)
	{
  	
		fprintf(f,"%s %s %d %d %s %s %s \n",C.Ref,C.Gp,C.Valmax,C.Valmin,C.typesort,C.typedit,C.etat);
		fclose(f);
		
  	}
	

}
void afficher_capteur(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char Ref[30];
	char Gp [30];
	char Valmax[30];
	char Valmin[30];
	char typedit[30];
	char typesort[30];
	char etat[30];
	store=NULL;
	FILE  *f;
	
	store = gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Reference", renderer,"text",EREF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Grandeur physique", renderer,"text",EGP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Valeur max", renderer,"text",EVALMAX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Valeur min", renderer,"text",EVALMIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Type de sortie", renderer,"text",ETYPESORT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Type de détection", renderer,"text",ETYPEDIT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("État", renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("Capteur.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f = fopen("Capteur.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s \n",Ref,Gp,Valmax,Valmin,typesort,typedit,etat)!=EOF)
		{
		
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EREF,Ref,EGP,Gp,EVALMAX,Valmax,EVALMIN,Valmin,ETYPESORT,typesort,ETYPEDIT,typedit,EETAT,etat,-1);
			
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
	}  
	}


}
void Modifier_Capteur(char Ref3[20])
{

	FILE *f=NULL;
	FILE *f1=NULL;
	f=fopen("Capteur.txt","r");
	f1=fopen("f1.txt","w+");

	Capteur ca;
	Capteur C;
	
	while(fscanf(f,"%s %s ",ca.Ref,ca.etat)!=EOF)
		{
			if(strcmp(C.Ref,ca.Ref)==0)
			{
				fprintf(f1,"%s %s \n",C.Ref,C.etat);
			}
			else
			{
			fprintf(f1,"%s %s \n",ca.Ref,ca.etat);
			}
		}


	
	fclose(f);
	fclose(f1);
	remove("Capteur.txt");
	rename("f1.txt","Capteur.txt");

}
void supprimer_capteur(char Ref2[20])
{
	
	FILE *f=NULL;
	FILE *tmp=NULL;

	Capteur C;
	f=fopen("Capteur.txt","r");
	tmp=fopen("tmp.txt","w");
//	printf("Donner reference ");
	
	if(f!=NULL)
	{
		while(fscanf(f,"%s %s %d %d %s %s %s",C.Ref,C.Gp,&C.Valmax,&C.Valmin,C.typesort,C.typedit,C.etat)!=EOF)
		{
			if(strcmp(C.Ref,Ref2)!=0)
			{
				fprintf(tmp,"%s %s %d %d %s %s %s \n",C.Ref,C.Gp,C.Valmax,C.Valmin,C.typesort,C.typedit,C.etat);
			}
		}


	}
	fclose(f);
	fclose(tmp);
	remove("Cateur.txt");
	rename("tmp.txt","Capteur.txt");


}


void afficherr_capteur(GtkWidget *liste)
{

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char Ref[30];
	char Gp [30];
	char Valmax[30];
	char Valmin[30];
	char typedit[30];
	char typesort[30];
	char etat[30];
	store=NULL;
	FILE  *tmp1;
	
	store = gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Reference", renderer,"text",EREF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Grandeur physique", renderer,"text",EGP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Valeur max", renderer,"text",EVALMAX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Valeur min", renderer,"text",EVALMIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Type de sortie", renderer,"text",ETYPESORT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Type de détection", renderer,"text",ETYPEDIT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("État", renderer,"text",EETAT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	tmp1=fopen("tmp1.txt","r");
	if(tmp1==NULL)
	{
		return;
	}
	else
	{
		tmp1 = fopen("tmp1.txt","a+");
		while(fscanf(tmp1,"%s %s %s %s %s %s %s \n",Ref,Gp,Valmax,Valmin,typesort,typedit,etat)!=EOF)
		{
		
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EREF,Ref,EGP,Gp,EVALMAX,Valmax,EVALMIN,Valmin,ETYPESORT,typesort,ETYPEDIT,typedit,EETAT,etat,-1);
			
		}
		fclose(tmp1);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
	}  
	}
}
