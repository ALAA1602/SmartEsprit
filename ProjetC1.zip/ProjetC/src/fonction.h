#include <gtk/gtk.h>
int verif(char log[],char Pw[]);
typedef struct date
{
int jours;
int mois;
int annee;


}date;
typedef struct etudiant
{
char id[9];
char classe[30];
//char cin[9];
//char nom[30];
//char prenom[30];
char binome[30];
date dn;
//char email[30];
//char tel[30];
int etage;
int chambre;


}etudiant;

void supprimer_etudiant(etudiant e);
void afficher_etudiant(GtkWidget *liste);
int verif(char log[],char Pw[]);
int verif2();
int verif3();
void modifier(etudiant e);
//void Ajouter_etudiant(etudiant e);
