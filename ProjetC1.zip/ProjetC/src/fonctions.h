
#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <string.h>
#include <gtk/gtk.h>

typedef struct
{
    char cin[20];
    char mdp[20];
   char role[20];
    char nom[20];
    char prenom[20];
     char sexe[20];
    int jour;
    int mois;
    int annee;
}utilisateur;

void  ajout_utilisateur(utilisateur t , int type);
void supprimer_utilisateur(char log[20]);
void modifer_utilisateur(char log[20] , utilisateur t2 , int type);
void affchercher_utilisateur(GtkWidget *liste);
//int chercher_utilisateur( );
void afficher_utilisateur(GtkWidget *liste);
void chercher_utilisateur(char log[20]);
#endif
