#include "fonction.h"
#include "fonctions.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{
EID,
EBINOME,
ECLASSE,
EETAGE,
ECHAMBRE,
EJOURS,
EMOIS,
EANNEE,
COLUMNS

};
int verif(char log[],char Pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
utilisateur t1;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,&t1.jour,&t1.mois,&t1.annee)!=EOF)
{
	if ((strcmp(t1.cin,log)==0)&&(strcmp(t1.mdp,Pw)==0)&&(strcmp(t1.role,"Technicien")==0))
	{trouve=1;}

	else if ((strcmp(t1.cin,log)==0)&&(strcmp(t1.mdp,Pw)==0)&&(strcmp(t1.role,"Nutritionniste")==0))
	{trouve=2;}
	else if ((strcmp(t1.cin,log)==0)&&(strcmp(t1.mdp,Pw)==0)&&(strcmp(t1.role,"Agent_foyer")==0))
	{trouve=3;}
}
fclose(f);
}
return (trouve);
}


int verif2()
{
int trouve2=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
utilisateur t1;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,&t1.jour,&t1.mois,&t1.annee)!=EOF)
{
	if ((strcmp(t1.role,"Technicien")==0))
	{
		trouve2=1;
	}
	/*else if ((strcmp(t1.role,"Agent_de_foyer")==0))
	{trouve2=2;}
	else 
	{trouve2=3;}*/

}
fclose(f);
}
return (trouve2);
}

int verif3()
{
int trouve2=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
utilisateur t1;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d  \n",t1.nom,t1.prenom,t1.cin,t1.mdp,t1.role,t1.sexe,&t1.jour,&t1.mois,&t1.annee)!=EOF)
{
	
	if ((strcmp(t1.role,"Agent_de_foyer")==0))
	{trouve2=2;}
	/*else 
	{trouve2=3;}*/

}
fclose(f);
}
return (trouve2);
}



void afficher_etudiant(GtkWidget *liste)
{
GtkCellRenderer  *renderer;
GtkTreeViewColumn  *column;
GtkTreeIter  iter;
GtkListStore  *store;
char id[30];
//char cin[30];
//char nom[30];
//char prenom[100];
char binome[100];
char classe[100];
//char email[30];
//char tel[30];
int etage;
int chambre;
int jours,mois,annee;
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();


column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);       
renderer=gtk_cell_renderer_text_new();



column=gtk_tree_view_column_new_with_attributes("Binome",renderer,"text",EBINOME,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();


column=gtk_tree_view_column_new_with_attributes("jours",renderer,"text",EJOURS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);  
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();

column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new(); 

column=gtk_tree_view_column_new_with_attributes("chambre",renderer,"text",ECHAMBRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();       
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("utilisateur1.txt","r");

if (f==NULL)
{
return;
}
else 
{
f= fopen("utilisateur1.txt","a+");
while (fscanf(f,"%s %s %s %d %d %d %d %d \n",id,classe,binome,&jours,&mois,&annee,&etage,&chambre)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EID,id,ECLASSE,classe,EBINOME,binome,EJOURS,jours,EMOIS,mois,EANNEE,annee,EETAGE,etage,ECHAMBRE,chambre,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);

}
}



/*void Ajouter_etudiant(etudiant e){
FILE *f=NULL;

}*/
void supprimer_etudiant(etudiant e) 
{

etudiant e2;
FILE *f,*g;
f=fopen("utilisateur1.txt","r");
g=fopen("tmp.txt","w");
if ((f==NULL) || (g==NULL))
{
return;
}
else
{
while (fscanf(f,"%s %s %s %d %d %d %d %d \n",e2.id,e2.classe,e2.binome,&e2.dn.jours,&e2.dn.mois,&e2.dn.annee,&e2.etage,&e2.chambre)!=EOF)
{
if (strcmp(e.id,e2.id)!=0)
fprintf(g,"%s %s %s %d %d %d %d %d \n",e2.id,e2.classe,e2.binome,e2.dn.jours,e2.dn.mois,e2.dn.annee,e2.etage,e2.chambre);
}
fclose(f);
fclose(g);
remove("utilisateur1.txt");
rename("tmp.txt","utilisateur1.txt");
}


}
void modifier(etudiant e)
{ 
char id1[9];
/*char cin1[9];
char nom1[30];
char prenom1[30];*/
char binome1[30];
//char email1[30];
//char tel1[30];
//etudiant e2;
int etage1;
int chambre1;
int jours1,mois1,annee1;
char classe1[30];
FILE *f=NULL;
FILE *g=NULL;
f=fopen("utilisateur1.txt","r");
g=fopen("tmp3.txt","a+");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %d %d %d %d %d \n",id1,classe1,binome1,&jours1,&mois1,&annee1,&etage1,&chambre1)!=EOF)
{
if (strcmp(id1,e.id)!=0)
{



fprintf(g,"%s %s %s %d %d %d %d %d \n",id1,classe1,binome1,jours1,mois1,annee1,etage1,chambre1);

}
else 
{
fprintf(g,"%s %s %s %d %d %d %d %d \n",e.id,e.classe,e.binome,e.dn.jours,e.dn.mois,e.dn.annee,e.etage,e.chambre);
}





}
}
fclose(f);
fclose(g);
remove("utilisateur1.txt");
rename("tmp3.txt","utilisateur1.txt");


}












